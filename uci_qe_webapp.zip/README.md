# UCI QE Duolingo-style Webapp

This repo combines:

* **Plumber API** (R) in `api/` for running code, returning flashcards, grading.
* **Next.js frontend** in `frontend/` for gamified UI (XP, streaks).
* **Dockerfile** for full-stack container (R, Quarto, Node).
* **start.sh** launches both backend (port 8000) and frontend (port 3000).

## Quickstart (Docker)

```bash
docker build -t uci-qe-web .
docker run -p 3000:3000 -p 8000:8000 uci-qe-web
```

Then navigate to `http://localhost:3000`.

Generated 2025-06-16T07:46:43.984394Z