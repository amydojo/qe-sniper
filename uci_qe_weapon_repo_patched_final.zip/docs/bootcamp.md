# 10-day Bootcamp schedule (see previous messages)
